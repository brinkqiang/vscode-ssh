0=${(%):-%N}
source ${0:A:h}/zsh-history-substring-search.zsh
